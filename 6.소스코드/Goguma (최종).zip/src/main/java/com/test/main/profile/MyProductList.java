package com.test.main.profile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.test.main.community.CommunityDTO;
import com.test.main.product.ProductDTO;

@WebServlet("/profile/myproductlist.do")
public class MyProductList extends HttpServlet {
	
	private ProfileDAO dao;
	private ArrayList<ProductDTO> list;
	private HashMap<String, String> map;
	private Calendar now;
	private String id;

	private int pageSize;	
	private int nowPage;

	
	{
		dao = new ProfileDAO();
		map = new HashMap<String,String>();
		now = Calendar.getInstance();

		pageSize = 7;
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		id = (String)req.getSession().getAttribute("id");
		setPage(req);
		try {
			list = dao.getMyProductList(map);			
		}catch(Exception e) {
		}

		refineData();

		req.setAttribute("list", list);
		req.setAttribute("nowPage", nowPage);
		req.setAttribute("pagebar", getPagebar());

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/profile/myproductlist.jsp");
		dispatcher.forward(req, resp);
	}

	private void refineData() {
		String strNow = String.format("%tF", now);
		for (ProductDTO dto : list) {
			
			if (dto.getRegdate().startsWith(strNow)) {
				dto.setRegdate(dto.getRegdate().substring(14));
			} else {
				String tmp = dto.getRegdate().substring(0, 10).replace("-", ".");
				dto.setRegdate(tmp.substring(2));
			}
			
			if (dto.getName().length() > 20) {
				dto.setName(dto.getName().substring(0, 20) + "..");
			}
			
			//제목에서 검색 중 > 검색어 강조!!
//			if (searchmode.equals("y") && column.equals("subject")) {
//				
//				//안녕하세요. 홍길동입니다.
//				//안녕하세요. <span style="">홍길동</span>입니다.
//				dto.setSubject(dto.getSubject().replace(word, "<span style='background-color:yellow;color:tomato;'>" + word + "</span>"));
//			}
		}
	}

	private void setPage(HttpServletRequest req) {
		int begin = 0;		
		int end = 0;	
		
		String search = req.getParameter("search");
		if(search == null) {
			search = "1";
		}

		String page = req.getParameter("page");

		if(page == null || page.equals("")) {
			nowPage = 1;
		} else {
			nowPage = Integer.parseInt(page);
		}

		begin = ((nowPage - 1) * pageSize) + 1;
		end = begin + pageSize - 1;
		
		String column = req.getParameter("column");
		String word = req.getParameter("word");
		String searchmode = "n";
		String id = (String) req.getSession().getAttribute("id");
		
		if ((column == null && word == null) || (column.equals("") && word.equals(""))) {
			word=" ";
			searchmode = "n";
		} else {
			searchmode = "y";
		}

		map.put("begin", begin + "");
		map.put("end", end + "");
		
		
		map.put("id", id);
	}

	private String getPagebar() {
		int totalCount = 0;
		int totalPage = 0;
		int blockSize = 10;
		int n;
		int loop;
		System.out.println(map.toString());
		totalCount = dao.getMyProductTotalPage(map);
		totalPage = (int)Math.ceil((double)totalCount / pageSize);

		String pagebar = "";
		
		loop = 1; 
		n = ((nowPage - 1) / blockSize) * blockSize + 1; 
		
		pagebar += "<nav><ul class=\"pagination\">";

		if (n == 1) {
			pagebar += String.format("<li class='nothing'><a href='#!' aria-label='Previous'><span class='glyphicon glyphicon-menu-left'></span></a></li>");
		} else {
			pagebar += String.format("<li class='previous'><a href='/goguma/profile/mycommunitylist.do?page=%d' aria-label='Previous'><span class='glyphicon glyphicon-menu-left'></span></a></li>", n-1);
		}

		while (!(loop > blockSize || n > totalPage)) {
			if (n == nowPage) {
				pagebar += String.format("<li class='active'><a href='#!'>%d</a></li>", n);
			} else {
				pagebar += String.format("<li><a href='/goguma/profile/mycommunitylist.do?page=%d'>%d</a></li>", n, n);
			}			
			loop++;
			n++;
		}

		if (n > totalPage) {
			pagebar += String.format("<li class='nothing'><a href='#!' aria-label='Next'><span class='glyphicon glyphicon-menu-right'></span></a></li>");
		} else {
			pagebar += String.format("<li class='next'><a href='/goguma/profile/mycommunitylist.do?page=%d' aria-label='Next'><span class='glyphicon glyphicon-menu-right'></span></a></li>", n);
		}

		pagebar += "</ul></nav>";
		return pagebar;
	}
}