package com.test.main.product;

public class ProductTypeDTO {
	private String product_type_seq;
	private String name;
	
	public String getProduct_type_seq() {
		return product_type_seq;
	}
	public void setProduct_type_seq(String product_type_seq) {
		this.product_type_seq = product_type_seq;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
