package com.test.main.product;

public class ProductDealDTO {
	private String deal_seq;
	private String id;
	private String product_seq;
	private String price;
	private String regdate;
	
	
	public String getDeal_seq() {
		return deal_seq;
	}
	public void setDeal_seq(String deal_seq) {
		this.deal_seq = deal_seq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getProduct_seq() {
		return product_seq;
	}
	public void setProduct_seq(String product_seq) {
		this.product_seq = product_seq;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}

}
