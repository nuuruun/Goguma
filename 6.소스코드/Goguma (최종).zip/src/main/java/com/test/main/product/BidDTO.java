package com.test.main.product;

public class BidDTO {
	private String bid_seq;
	private String id;
	private String product_seq;
	private String price;
	private String time;
	public String getBid_seq() {
		return bid_seq;
	}
	public void setBid_seq(String bid_seq) {
		this.bid_seq = bid_seq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getProduct_seq() {
		return product_seq;
	}
	public void setProduct_seq(String product_seq) {
		this.product_seq = product_seq;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
	
}
