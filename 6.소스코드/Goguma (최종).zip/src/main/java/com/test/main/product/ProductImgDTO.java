package com.test.main.product;

public class ProductImgDTO {
	private String product_img_seq;
	private String product_seq;
	private String path;
	
	public String getProduct_img_seq() {
		return product_img_seq;
	}
	public void setProduct_img_seq(String product_img_seq) {
		this.product_img_seq = product_img_seq;
	}
	public String getProduct_seq() {
		return product_seq;
	}
	public void setProduct_seq(String product_seq) {
		this.product_seq = product_seq;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	
}
