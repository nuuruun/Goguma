package com.test.main.admin;

public class QuestionDTO {
	
	private String questionSeq;
	private String type;
	private String title;
	private String regDate;
	private String answerSeq;
	private String state;

	public String getQuestionSeq() {
		return questionSeq;
	}

	public void setQuestionSeq(String questionSeq) {
		this.questionSeq = questionSeq;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getRegDate() {
		return regDate;
	}

	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}

	public String getAnswerSeq() {
		return answerSeq;
	}

	public void setAnswerSeq(String answerSeq) {
		this.answerSeq = answerSeq;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
	
}
