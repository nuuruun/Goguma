package com.test.main.product;

public class ProductAddressDTO {
	private String sido;
	private String sgg;
	private String emd;
	private String address_seq;
	
	public String getSido() {
		return sido;
	}
	public void setSido(String sido) {
		this.sido = sido;
	}
	public String getSgg() {
		return sgg;
	}
	public void setSgg(String sgg) {
		this.sgg = sgg;
	}
	public String getEmd() {
		return emd;
	}
	public void setEmd(String emd) {
		this.emd = emd;
	}
	public String getAddress_seq() {
		return address_seq;
	}
	public void setAddress_seq(String address_seq) {
		this.address_seq = address_seq;
	}
}
