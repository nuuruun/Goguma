package com.test.main;

public class Test {
	
	public static void main(String[] args) {
		int a = (int)Math.round((double)5.45960648);
		
		System.out.println(a);
	}

}
